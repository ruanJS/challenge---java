package br.com.fiap.id.model;

import br.com.fiap.id.repository.ManyToMany;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "courses")
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    private String name;

    @NotNull
    private String description;

    @ManyToMany(mappedBy = "courses")
    private Set<User> users = new HashSet<>();

    public void clone(Object name) {
    }

    public void toString(Object description) {
    }

    public void setDescription(Object description) {
    }

    public String getNome() {
        return null;
    }

    public Object getDescription() {
        return null;
    }

    // Getters and setters
}
