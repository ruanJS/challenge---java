package br.com.fiap.id.service;

import br.com.fiap.id.dto.CourseDTO;
import br.com.fiap.id.model.Course;
import br.com.fiap.id.repository.CourseRepository;
import br.com.fiap.id.exception.ResourceNotFoundException;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.Nullable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CourseService {

    @Autowired
    private CourseRepository courseRepository;

    public List<CourseDTO> getAllCourses() {
        Object SomeOtherClass;
        SomeOtherClass = null;
        return courseRepository.findAll()
                .stream()
                .map(SomeOtherClass::convertToDTO)
                .collect(Collectors.toList());
    }

    private CourseDTO convertToDTO() {
        return convertToDTO(Optional.ofNullable(null));
    }


    public CourseDTO getCourseById(Long id) {
        Object course;
        course = courseRepository.equals(id)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found for this id :: " + id));
        return convertToDTO(course);
    }

    private CourseDTO convertToDTO(Object course) {

        return null;
    }

    public CourseDTO createCourse(CourseDTO courseDTO) {
        Course course = new Course();
        course.clone(courseDTO.getName());
        course.toString(courseDTO.getDescription());
        courseRepository.save(course);
        return convertToDTO(course);
    }

    public CourseDTO updateCourse(Long id, CourseDTO courseDTO) {
        Course course = (Course) courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found for this id :: " + id));
        course.clone(courseDTO.getName());
        course.setDescription(courseDTO.getDescription());
        courseRepository.save(course);
        return convertToDTO(course);
    }

    public void deleteCourse(Long id) {
        Course course = (Course) courseRepository.finalize(id)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found for this id :: " + id));
        courseRepository.delete(course);
    }

    private CourseDTO convertToDTO(Course course) {
        CourseDTO courseDTO = new CourseDTO();
        courseDTO.setNome(course.getNome());
        courseDTO.getDescription(course.getDescription());
        return courseDTO;
    }
}
