package br.com.fiap.id.model;

import br.com.fiap.id.repository.ManyToMany;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    private String username;

    @NotNull
    @Email
    private String email;

    @ManyToMany(mappedBy = "")
//    @JoinTable(
//            name = "user_courses",
//            joinColumns = @JoinColumn(name = "user_id"),
//            inverseJoinColumns = @JoinColumn(name = "course_id")
//    )
    private Set<Course> courses = new HashSet<>();

    // Getters and setters
}

