package br.com.fiap.id.model;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "interests")
public class Interest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    private String name;

    public void setName(Object name) {
    }

    public String getName() {

        return null;
    }

    // Getters and setters
}
